import axios from 'axios';


const EMP_REST_URL='http://localhost:8080/emp/';


class Empservice{

    getEmp(){
    return axios.get(EMP_REST_URL);
}

addEmp(SaveEmp){
    return axios.post(EMP_REST_URL, SaveEmp);

}

getEmpById(eid){
    return axios.get(EMP_REST_URL + '/' + eid);
}

updateEmp(emp, eid){
    return axios.put(EMP_REST_URL + '/'+ eid, emp);
}
deleteEmp(eid){
    return axios.delete(EMP_REST_URL + '/' + eid);
}
}
export default new Empservice()