
import './App.css';
import {BrowserRouter as Router, Route, Switch}from 'react-router-dom';
import EmployeeListComp from './empComp/EmployeeListComp';
import HeaderComp from './empComp/HeaderComp';
import AddEmp from './empComp/AddEmp';
import updateEmp from './empComp/updateEmp';
function App() {
  return (
    <div>
      <Router>
        <div className="container">
          <HeaderComp />
          <div className="container">
            <Switch>
              <Route exact  path="/" component={EmployeeListComp} />
              <Route path="/emp" component={EmployeeListComp} />
              <Route path="/addemp" component={AddEmp} />
            <Route path="/updateemp/:id" component={updateEmp} />
             
            </Switch>
          </div>
          
        </div>
      </Router>
    </div >
  );
}

export default App;
