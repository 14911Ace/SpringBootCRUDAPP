import React, { Component } from 'react';
import Empservice from '../empService/Service'
class EmployeeListComp extends Component {

    constructor(props){
        super(props)

        this.state={
            emp: [ ]
        }
        this.deleteEmp=this.deleteEmp.bind(this);
        this.addemp = this.addemp.bind(this);
        this.editEmp = this.editEmp.bind(this);
    }
    editEmp(eid ){
            this.props.history.push(`/updateemp/${eid}`)
    }

    deleteEmp(eid){
        Empservice.deleteEmp(eid).then((res)=> {
        this.setState({emp:this.state.emp.filter(emp=>emp.eid !=eid)});
        })
        this.props.history.push('/')
    }
    

    
        componentDidMount(){
            Empservice.getEmp().then((res)=>{
                        this.setState({emp: res.data});
            });
        }

    
        addemp()
        {
            this.props.history.push('/addemp');
        }

    render() {
        return (
            <div>
               <h2 className="text-center"> Employee List</h2>
               <div className= "row">
                   <button className="btn btn-primary" onClick={this.addemp}> Add Employee </button>
               </div>
               <div className="row">
                   <table class = "table table-stripe table-bordered">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                            <th>Employee Department</th>
                            <th>Action</th>

                        </tr>

                    </thead>

                    <tbody>
                     {
                        this.state.emp.map(
                            emp =>
                             <tr key={emp.eid}>
                                 <td>{emp.eid}</td>
                                <td>{emp.ename}</td>
                                <td>{emp.depart}</td>       
                                    <td>
                                        <button type="button" onClick={()=>this.editEmp(emp.eid)} className= "btn btn-info"> UPDATE </button>
                                        <button onClick={()=>this.deleteEmp(emp.eid)} className= "btn btn-danger"> DELETE </button>
                                    </td>
                                </tr>
                            )
                        }


                    </tbody>
                   </table>
                   </div> 
            </div>
        );
    }
}

export default EmployeeListComp;