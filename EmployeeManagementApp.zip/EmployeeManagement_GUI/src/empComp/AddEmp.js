import React, { Component } from 'react';
import Empservice from '../empService/Service';

class AddEmp extends Component {
constructor(props){
    super(props)
    // this.saveEmp=this.saveEmp.bind(this);
    // this.cancel= this.cancel.bind(this);

    this.state={
        eid:this.props.match.params.eid,
        eid:'',
        ename:'',
        depart:''


    };
    this.changeIdHandler = this.changeIdHandler.bind(this);

    this.changeDepartHandler = this.changeDepartHandler.bind(this);

    this.changeFullNameHandler = this.changeFullNameHandler.bind(this);

    this.saveEmp = this.saveEmp.bind(this);

   this.cancel = this.cancel.bind(this);

} 
componentDidMount(){
         
    if (this.state.eid == -1) {
        return
    }
    else {
        Empservice.getEmpById(this.state.eid).then((res) => {
            let emp = res.data;
            this.setState({ eid: emp.eid, ename: emp.ename, depart: emp.depart });
        });
    }


    
}
saveEmp = (e)=> {
    e.preventDefault();
    let saveEmp = {eid:this.state.eid, ename:this.state.ename, depart: this.state.depart};
        console.log('employee =>' + JSON.stringify(saveEmp));
    
        
            Empservice.addEmp(saveEmp).then(res=>{
                this.props.history.push("/");
            })
        
     
            Empservice.updateEmp(saveEmp, this.state.eid).then(res=>{

                this.props.history.push('/emp');
            })
        
 
}

changeIdHandler=(event)=>{
    this.setState({eid:event.target.value});
}
changeFullNameHandler=(event)=>{
    this.setState({ename:event.target.value});
}
changeDepartHandler=(event)=>{
    this.setState({depart:event.target.value});
}
cancel(){
    this.props.history.push('/');
}
  

 
    render() {
        return (
            <div>
               <div className="container">
                   <div className="row">
                       <div className="card col-md-6 offset-md-3 offset-md-3">
                            <h3 className="text-center> " > Add Employee </h3>
                            <div className="card-body">
                                <form>
                                <div className="form-group">
                                        <label> Employee Id : </label>
                                        <input placeholder="Employee id" name="eid" className="form-control"
                                        value={this.state.eid} onChange={this.changeIdHandler}/>
                                    </div>
                                    
                                    <div className="form-group">
                                        <label> Employee Full Name : </label>
                                        <input placeholder="Full Name" name="ename" className="form-control"
                                        value={this.state.ename} onChange={this.changeFullNameHandler}/>
                                    </div>
                                   

                                    <div className="form-group">
                                        <label> Employee Department : </label>
                                        <input placeholder="Employee depart" name="depart" className="form-control"
                                        value={this.state.depart} onChange={this.changeDepartHandler}/>
                                    </div>

                             <button className="btn btn-success" onClick={this.saveEmp}>Add</button>  
                             <button className="btn btn-danger" onClick={this.cancel} style= {{marginLeft:"10px"}}>Cancel</button>     
                                </form>
                            </div>
                       </div>
                   </div>
               </div>
            </div>
        );
    }
}

export default AddEmp;