package com.project.EmployeManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
