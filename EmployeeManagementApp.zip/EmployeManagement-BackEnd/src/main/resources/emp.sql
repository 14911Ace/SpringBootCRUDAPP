INSERT INTO EMPLOYEE values  VALUES (1, 'raja', 'Jr.Developer');
