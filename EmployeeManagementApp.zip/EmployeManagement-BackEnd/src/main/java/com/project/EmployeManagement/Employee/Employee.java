package com.project.EmployeManagement.Employee;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Employee {
	
	@Id
	@GeneratedValue
	private int eid;
	private String ename;
	private String depart;
	
	
	public Employee() {
		
	}
	public Employee(int eid, String ename, String depart) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.depart = depart;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getDepart() {
		return depart;
	}
	public void setDepart(String depart) {
		this.depart = depart;
	}
	
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", depart=" + depart + "]";
	}

}
