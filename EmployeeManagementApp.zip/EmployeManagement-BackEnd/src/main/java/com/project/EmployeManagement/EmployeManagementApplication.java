package com.project.EmployeManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.EmployeManagement.Employee.Employee;
import com.project.EmployeManagement.Repo.EmployeeRepo;

@SpringBootApplication
public class EmployeManagementApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(EmployeManagementApplication.class, args);
		
		
	}
@Autowired
	private EmployeeRepo repo;
	
	@Override
	public void run(String... args) throws Exception {
		this.repo.save(new Employee (1, "Raja ", " Jr. Developer"));
		this.repo.save(new Employee (2, "Baja ", " Sr. Developer"));
		
		
		
		
	}

}
