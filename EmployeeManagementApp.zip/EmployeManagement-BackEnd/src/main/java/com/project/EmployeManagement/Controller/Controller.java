package com.project.EmployeManagement.Controller;

import java.util.List;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.ResourceAccessException;

import com.project.EmployeManagement.Employee.Employee;
import com.project.EmployeManagement.Repo.EmployeeRepo;



@CrossOrigin(origins = "http://localhost:3001")
@RestController
@RequestMapping("/")
public class Controller {
	
	
	
	@Autowired
	private EmployeeRepo repo;
	
	@GetMapping("/emp")
	public List<Employee> getAllEmployee(String eid) 
	{
		return repo.findAll();
	}
	
		// creating new Emp
	@PostMapping("/emp")
	public Employee createEmp(@RequestBody Employee emp) {
		
		return repo.save(emp);
	}
	// getting emloyee by ID
	@GetMapping("/emp/{eid}")
	public Employee getEmpById(@PathVariable int eid) {
		
		
		return repo.findById(eid).orElseThrow(()->new ResourceAccessException("Employee not found" + eid));
	}
	
	//updating employee
	@PutMapping("/emp/{eid}")
	public Employee updateEmp(@PathVariable ("eid") int eid , @RequestBody Employee ename){
		
		return repo.save(ename);
		
	}
	// deleing employee by id
	@DeleteMapping("/emp/{eid}")
	public String deletEmployee(@PathVariable("eid")int eid) {
		 repo.deleteById(eid);
		 return " delete sucessfull";
}		
}
